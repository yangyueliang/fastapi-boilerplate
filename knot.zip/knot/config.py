import os
from pathlib import Path

from pydantic import BaseSettings


class Settings(BaseSettings):
    HOME_DIR: str = None

    # ---------- Celery ----------
    CELERY_BROKER_URI = "redis://127.0.0.1:6379/0"
    CELERY_RESULT_BACKEND_URI = "redis://127.0.0.1:6379/1"

    # ---------- Frontend ----------
    KNOT_API_URL = "http://127.0.0.1:8000/api"
    KNOT_FLOWER_URL = "http://127.0.0.1:5555"
    KNOT_ENABLE_HISTORY_MODE = False
    KNOT_REFRESH_INTERVAL = 30000
    KNOT_REPO_LINK = "https://github.com/ovh/celery-director"
    KNOT_DOCUMENTATION_LINK = "https://ovh.github.io/celery-director"

    # ---------- API ----------
    KNOT_WORKFLOWS_PER_PAGE = 1000
    KNOT_AUTH_ENABLED = False

    # These settings are designed to be used with the "director dlassets" command,
    # the DIRECTOR_STATIC_FOLDER will be used if you set DIRECTOR_ENABLE_CDN to false.
    KNOT_ENABLE_CDN = True

    # ---------- Retention ----------
    KNOT_DEFAULT_RETENTION_OFFSET = 1000

    @property
    def WORK_DIR(self) -> str:
        if self.HOME_DIR and os.path.exists(self.HOME_DIR):
            return self.HOME_DIR
        return os.curdir

    @property
    def KNOT_HOME(self) -> str:
        base_dir = os.path.dirname(__file__)
        return str(Path(base_dir).resolve())

    @property
    def STATIC_HOME(self) -> str:
        return os.path.join(self.KNOT_HOME, "static")

    @property
    def TEMPLATE_HOME(self) -> str:
        return os.path.join(self.KNOT_HOME, "templates")

    class Config:
        env_file = ".env"


settings = Settings()
