class BizException(Exception):
    pass


class WorkflowNotFound(BizException):
    pass


class SchemaNotFound(BizException):
    pass


class SchemaNotValid(BizException):
    pass


class WorkflowSyntaxError(BizException):
    pass


class TaskNotFound(BizException):
    pass

