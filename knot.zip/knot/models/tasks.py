from sqlalchemy import Column, String, Enum, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.types import PickleType
from sqlalchemy_utils import UUIDType

from knot.models import BaseModel, StatusType
from knot.models.utils import JSONBType


class Task(BaseModel):
    __tablename__ = "tasks"

    key = Column(String(255), nullable=False)
    status = Column(Enum(StatusType), default=StatusType.pending, nullable=False)
    previous = Column(JSONBType, default=[])
    result = Column(PickleType)

    # Relationship
    workflow_id = Column(
        UUIDType(binary=False),
        ForeignKey("workflows.id", ondelete="cascade"),
        nullable=False,
        index=True,
    )
    # workflow = relationship("Workflow", lazy="joined")
    # workflow = relationship(
    #     "Workflow", backref=backref("tasks", lazy=True), cascade="all,delete"
    # )
    workflow = relationship("Workflow", lazy="joined", innerjoin=True)

    def __repr__(self):
        return f"<Task {self.key}>"

    def to_dict(self):
        d = super().to_dict()
        d.update(
            {
                "key": self.key,
                "status": self.status.value,
                "task": self.id,
                "previous": self.previous,
                "result": self.result,
            }
        )
        return d
