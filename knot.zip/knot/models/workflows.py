from sqlalchemy import Column, String, Enum, Boolean
from sqlalchemy.orm import relationship

from knot.models import BaseModel, StatusType
from knot.models.tasks import Task
from knot.models.utils import JSONBType


class Workflow(BaseModel):
    __tablename__ = "workflows"

    name = Column(String(255), nullable=False)
    project = Column(String(255), nullable=False)
    status = Column(Enum(StatusType), default=StatusType.pending, nullable=False)
    payload = Column(JSONBType, default={})
    periodic = Column(Boolean, default=False)
    tasks = relationship(Task, lazy="joined", innerjoin=True)

    def __str__(self):
        return f"{self.project}.{self.name}"

    def __repr__(self):
        return f"<Workflow {self.project}.{self.name}>"

    def to_dict(self, with_payload=True):
        d = super().to_dict()
        d.update(
            {
                "name": self.name,
                "project": self.project,
                "fullname": f"{self.project}.{self.name}",
                "status": self.status.value,
                "periodic": self.periodic,
            }
        )
        if with_payload:
            d["payload"] = self.payload
        return d
