import enum
import uuid

from sqlalchemy import Column, func, DateTime
from sqlalchemy.orm import Session
from sqlalchemy_utils import UUIDType

from knot.database import Base


def get_uuid():
    return str(uuid.uuid4())


class StatusType(enum.Enum):
    pending = "pending"
    progress = "progress"
    success = "success"
    error = "error"
    canceled = "canceled"


class BaseModel(Base):
    __abstract__ = True

    id = Column(
        UUIDType(binary=False), primary_key=True, nullable=False, default=get_uuid
    )
    created_at = Column(
        DateTime(timezone=True), default=func.now(), nullable=False, index=True
    )
    updated_at = Column(
        DateTime(timezone=True),
        default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    def save(self, db: Session):
        db.add(self)
        db.commit()
        db.refresh(self)
        return self

    def to_dict(self):
        return {
            "id": self.id,
            "created": self.created_at.isoformat(),
            "updated": self.updated_at.isoformat(),
        }
