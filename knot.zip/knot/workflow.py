import json
from json import JSONDecodeError
from pathlib import Path
from typing import TypeVar, Dict, List, Optional

import yaml
from pluginbase import PluginBase
from pydantic import BaseModel

from knot.config import settings
from knot.exception import SchemaNotValid, SchemaNotFound, WorkflowNotFound

Self = TypeVar("Self", bound="FlowUnit")


class FlowUnit(BaseModel):
    name: str
    type: str
    queue: Optional[str]
    props: Dict = {}
    children: List[Self] = []
    parent: Optional[Self] = None

    def print_tree(self, level=0):
        print("  " * level, "+", f"{self.name}(type={self.type})")
        for child in self.children:
            child.print_tree(level + 1)

    def is_task(self) -> bool:
        return self.type == "task"

    def is_chain(self) -> bool:
        return self.type == "chain"

    def is_group(self) -> bool:
        return self.type == "group"


class CeleryWorkflow:
    def __init__(self):
        self.workflows = None

    def initialize(self):
        path = Path(settings.WORK_DIR).resolve() / "workflows.yml"
        with open(path) as f:
            self.workflows = yaml.load(f, Loader=yaml.SafeLoader)

        self.import_user_tasks()
        self.read_schemas()

    def get_by_name(self, name):
        workflow = self.workflows.get(name)
        if not workflow:
            raise WorkflowNotFound(f"Workflow {name} not found")
        return workflow

    def get_tasks(self, name):
        return self.get_by_name(name)["tasks"]

    @staticmethod
    def import_user_tasks():
        plugin_base = PluginBase(package="knot.plugins")

        folder = Path(settings.WORK_DIR).resolve()
        plugin_source = plugin_base.make_plugin_source(
            searchpath=[str(folder)]
        )

        tasks = Path(folder / "tasks").glob("**/*.py")
        with plugin_source:
            for task in tasks:
                if task.stem == "__init__":
                    continue

                name = str(task.relative_to(folder))[:-3].replace("/", ".")
                __import__(
                    plugin_source.base.package + "." + name,
                    globals(),
                    {},
                    ["__name__"],
                )

    def read_schemas(self):
        folder = Path(settings.WORK_DIR).resolve()

        for name, conf in self.workflows.items():
            if "schema" in conf:
                path = Path(folder / "schemas" / f"{conf['schema']}.json")

                try:
                    schema = json.loads(open(path).read())
                except FileNotFoundError:
                    raise SchemaNotFound(
                        f"Schema '{conf['schema']}' not found ({path})"
                    )
                except JSONDecodeError as e:
                    raise SchemaNotValid(f"Schema '{conf['schema']}' not valid ({e})")

                self.workflows[name]["schema"] = schema
