from knot.cel_ext import cel
from knot.config import Settings
from knot.workflow import CeleryWorkflow

settings = Settings()
cel_wf = CeleryWorkflow()


def initialize():
    cel.conf.update(
        task_serializer='json',
        accept_content=['json'],  # Ignore other content
        result_serializer='json',
        broker_url=settings.CELERY_BROKER_URI,
        result_backend=settings.CELERY_RESULT_BACKEND_URI,
        include=[
            "knot.tasks.workflow"
        ]
    )
    cel_wf.initialize()


initialize()
