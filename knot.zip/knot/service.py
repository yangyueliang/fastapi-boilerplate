import contextlib
import typing

from sqlalchemy.orm import Session, lazyload, eagerload

from knot.database import SessionLocal
from knot.exception import WorkflowNotFound, TaskNotFound
from knot.models import StatusType
from knot.models.tasks import Task
from knot.models.workflows import Workflow


@contextlib.contextmanager
def get_db_session() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class TaskService:

    @classmethod
    def create_task(cls, task_id: str, key: str, previous: typing.List, workflow_id: str, status: StatusType):
        with get_db_session() as db:
            task = Task(
                id=task_id,
                key=key,
                previous=previous or [],
                workflow_id=workflow_id,
                status=status,
            )
            task.save(db)
            return task

    @classmethod
    def get_task(cls, task_id):
        with get_db_session() as db:
            task = db.query(Task).filter_by(id=task_id).first()
            if not task:
                raise TaskNotFound(task_id)
            return task

    @classmethod
    def save_task(cls, task: Task):
        with get_db_session() as db:
            task.save(db)


class WorkflowService:

    @classmethod
    def list_workflows(cls, page: int = 1, per_page: int = 10):
        with get_db_session() as db:
            return db.query(Workflow).order_by(Workflow.created_at.desc()) \
                .offset(per_page * (page - 1)).limit(per_page).all()

    @classmethod
    def get_workflow(cls, workflow_id: str):
        with get_db_session() as db:
            workflow = db.query(Workflow).options(eagerload(Workflow.tasks)) \
                .filter_by(id=workflow_id).first()
            if not workflow:
                raise WorkflowNotFound(f"Workflow {workflow_id} not found")
            return workflow

    @classmethod
    def create_workflow(cls, project: str, name: str, payload: typing.Dict):
        # Create the workflow in DB
        obj = Workflow(project=project, name=name, payload=payload)
        with get_db_session() as db:
            obj.save(db)
        return obj

    @classmethod
    def save_workflow(cls, wf: Workflow):
        with get_db_session() as db:
            wf.save(db)

    @classmethod
    def change_status(cls, workflow_id: str, new_status: StatusType):
        workflow = cls.get_workflow(workflow_id)
        with get_db_session() as db:
            workflow.status = new_status
            workflow.save(db)


class UserService:
    pass
