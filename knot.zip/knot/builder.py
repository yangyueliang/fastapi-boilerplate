import typing

from celery import chain, group, signature
from celery.utils import uuid

from knot import cel_wf
from knot.exception import WorkflowSyntaxError
from knot.models import StatusType
from knot.service import WorkflowService, TaskService
from knot.tasks.workflow import start, end
from knot.workflow import FlowUnit


class WorkflowBuilder(object):
    def __init__(self, workflow_id):
        self.workflow_id = workflow_id
        self._workflow = None
        self.root = self._parse(cel_wf.get_tasks(str(self.workflow)))

    @property
    def workflow(self):
        if not self._workflow:
            self._workflow = WorkflowService.get_workflow(self.workflow_id)
        return self._workflow

    @staticmethod
    def _parse(cfg_dict: typing.Dict):
        root = FlowUnit(**cfg_dict)
        return root

    def new_task(self, unit: FlowUnit, previous: typing.List = None):
        task_id = uuid()

        # We create the Celery task specifying its UID
        sig = signature(unit.name,
                        kwargs={"workflow_id": self.workflow_id, "props": unit.props},
                        task_id=task_id,
                        queue=unit.queue)

        # Director task has the same UID
        TaskService.create_task(
            task_id,
            unit.name,
            previous or [],
            self.workflow.id,
            StatusType.pending
        )

        return sig

    def build_dag(self):
        def _build(unit: FlowUnit, previous: typing.List = None):
            if previous is None:
                previous = []
            if unit.is_task():
                sig = self.new_task(unit, previous)
                return sig, [sig.id]
            elif unit.is_chain() and unit.children:
                sub_tasks = []
                for sub_unit in unit.children:
                    sig, previous = _build(sub_unit, previous)
                    sub_tasks.append(sig)
                return chain(*sub_tasks, task_id=uuid(), queue=unit.queue), previous
            elif unit.is_group() and unit.children:
                g_previous = []
                sub_tasks = []
                for sub_unit in unit.children:
                    sig, previous = _build(sub_unit, previous)
                    sub_tasks.append(sig)
                    g_previous.extend(previous)
                return group(sub_tasks, task_id=uuid(), queue=unit.queue), g_previous
            else:
                raise WorkflowSyntaxError(f"{unit}")

        workflow, _ = _build(self.root)
        return chain(start.si(self.workflow_id), workflow, end.si(self.workflow_id))

    def run(self):
        canvas = self.build_dag()

        try:
            return canvas.apply_async()
        except Exception as e:
            WorkflowService.change_status(self.workflow_id, StatusType.error)
            self.workflow.status = StatusType.error
            raise e

#
# if __name__ == "__main__":
#     import yaml
#
#     with open("/Users/wenfeiyang/workspace/celery-orchestrator/workflows.yml", 'r') as reader:
#         data = yaml.safe_load(reader)
#         for key, cfg in data.items():
#             builder = WorkflowBuilder(cfg["tasks"])
#             r = builder.run()
