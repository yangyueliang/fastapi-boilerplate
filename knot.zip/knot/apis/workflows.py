import typing

from fastapi import APIRouter
from pydantic import BaseModel

from knot import cel_wf
from knot.builder import WorkflowBuilder
from knot.service import WorkflowService

router = APIRouter(prefix="/api")


def _execute_workflow(project, name, payload=None):
    if payload is None:
        payload = {}

    fullname = f"{project}.{name}"

    # Check if the workflow exists
    wf = cel_wf.get_by_name(fullname)

    # Create the workflow in DB
    obj = WorkflowService.create_workflow(project=project, name=name, payload=payload)

    # Build the workflow and execute it
    workflow = WorkflowBuilder(obj.id)
    workflow.run()

    return obj.to_dict()


class CreateWorkflowReq(BaseModel):
    project: str
    name: str
    payload: typing.Dict


@router.post("/workflows")
def create_workflow(req: CreateWorkflowReq):
    data = _execute_workflow(req.project, req.name, req.payload)
    return data


@router.get("/workflows")
def list_workflows(page: int = 1, per_page: int = 10, with_payload: bool = True):
    workflows = WorkflowService.list_workflows(page=page, per_page=per_page)
    return [w.to_dict(with_payload=with_payload) for w in workflows]


@router.get("/workflows/{workflow_id}")
def get_workflow(workflow_id):
    workflow = WorkflowService.get_workflow(workflow_id)
    tasks = [t.to_dict() for t in workflow.tasks]

    resp = workflow.to_dict()
    resp.update({"tasks": tasks})
    return resp


@router.get("/definitions")
def list_definitions():
    from knot import cel_wf
    workflow_definitions = []
    for fullname, definition in sorted(cel_wf.workflows.items()):
        project, name = fullname.split(".", 1)
        workflow_definitions.append(
            {"fullname": fullname, "project": project, "name": name, **definition}
        )
    return workflow_definitions
