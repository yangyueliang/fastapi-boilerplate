import os.path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request
from starlette.responses import HTMLResponse

from knot.apis.workflows import router
from knot.config import Settings

settings = Settings()

BASE_DIR = os.path.dirname(__file__)

app = FastAPI()
app.include_router(router)
app.mount("/static", StaticFiles(directory=settings.STATIC_HOME), name="static")
templates = Jinja2Templates(directory=settings.TEMPLATE_HOME, variable_start_string="{[", variable_end_string="]}")


@app.get("/status")
def status():
    return "ok"


@app.get("/", response_class=HTMLResponse)
async def read_item(request: Request):
    return templates.TemplateResponse("index.html", {
        "request": request,
        "config": settings
    })


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, port=8080)
