from celery.utils.log import get_task_logger

from knot.cel_ext import cel
from knot.models import StatusType
from knot.service import WorkflowService

logger = get_task_logger(__name__)


@cel.task()
def start(workflow_id):
    logger.info(f"Opening the workflow {workflow_id}")
    WorkflowService.change_status(workflow_id, StatusType.progress)


@cel.task()
def end(workflow_id):
    logger.info(f"Closing the workflow {workflow_id}")
    workflow = WorkflowService.get_workflow(workflow_id)

    if workflow.status != StatusType.error:
        workflow.status = StatusType.success
        WorkflowService.save_workflow(workflow)
