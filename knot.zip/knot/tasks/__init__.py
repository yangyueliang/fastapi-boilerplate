from celery import Task
from celery.utils.log import get_task_logger

from knot.models import StatusType
from knot.service import TaskService

logger = get_task_logger(__name__)


class BaseTask(Task):
    def on_failure(self, exc, task_id, args, kwargs, einfo):
        _task = TaskService.get_task(task_id)
        _task.status = StatusType.error
        _task.result = {"exception": str(exc), "traceback": einfo.traceback}
        _task.workflow.status = StatusType.error
        TaskService.save_task(_task)

        logger.info(f"Task {task_id} is now in error")
        super(BaseTask, self).on_failure(exc, task_id, args, kwargs, einfo)

    def on_success(self, retval, task_id, args, kwargs):
        _task = TaskService.get_task(task_id)
        _task.status = StatusType.success
        _task.result = retval
        TaskService.save_task(_task)

        logger.info(f"Task {task_id} is now in success")
        super(BaseTask, self).on_success(retval, task_id, args, kwargs)
