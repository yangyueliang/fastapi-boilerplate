from functools import partial

from celery import Celery

from knot.config import Settings
from knot.tasks import BaseTask

settings = Settings()
cel = Celery("knot")
task = partial(cel.task, base=BaseTask)

